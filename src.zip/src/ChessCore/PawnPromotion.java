package ChessCore;

public enum PawnPromotion {
    None,
    Knight,
    Bishop,
    Rook,
    Queen,
}
