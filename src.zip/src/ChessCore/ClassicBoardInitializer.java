package ChessCore;

import ChessCore.Pieces.*;

public final class ClassicBoardInitializer implements BoardInitializer {
    private static final BoardInitializer instance = new ClassicBoardInitializer();

    public ClassicBoardInitializer() {
    }

    public static BoardInitializer getInstance() {
        return instance;
    }

    @Override
   public Piece[][] initialize() {
        BoardFactory boardFactory = new BoardFactory();
        return boardFactory.boardCreator();
}
}
