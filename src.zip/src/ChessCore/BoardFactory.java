/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ChessCore;

import ChessCore.Pieces.Bishop;
import ChessCore.Pieces.King;
import ChessCore.Pieces.Knight;
import ChessCore.Pieces.Pawn;
import ChessCore.Pieces.Piece;
import ChessCore.Pieces.PieceFactory;
import ChessCore.Pieces.Queen;
import ChessCore.Pieces.Rook;

/**
 *
 * @author Win11
 */
public class BoardFactory {
    
    public Piece[][] boardCreator() {
        PieceFactory pieceFactory = new PieceFactory();
        

        return new Piece[][] {
            {pieceFactory.createPiece("Rook", Player.WHITE), pieceFactory.createPiece("Knight", Player.WHITE), pieceFactory.createPiece("Bishop", Player.WHITE), pieceFactory.createPiece("Queen", Player.WHITE), pieceFactory.createPiece("King", Player.WHITE), pieceFactory.createPiece("Bishop", Player.WHITE), pieceFactory.createPiece("Knight", Player.WHITE), pieceFactory.createPiece("Rook", Player.WHITE)},
            {pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE), pieceFactory.createPiece("Pawn", Player.WHITE)},
            {null, null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null, null},
            {null, null, null, null, null, null, null, null},
            {pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK), pieceFactory.createPiece("Pawn", Player.BLACK)},
            {pieceFactory.createPiece("Rook", Player.BLACK), pieceFactory.createPiece("Knight", Player.BLACK), pieceFactory.createPiece("Bishop", Player.BLACK), pieceFactory.createPiece("Queen", Player.BLACK), pieceFactory.createPiece("King", Player.BLACK), pieceFactory.createPiece("Bishop", Player.BLACK), pieceFactory.createPiece("Knight", Player.BLACK), pieceFactory.createPiece("Rook", Player.BLACK)}
        };
    }
}